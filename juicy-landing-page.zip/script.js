document.addEventListener('DOMContentLoaded', () => {
  initThreeJS();
  initGSAPAnimations();
});

function initThreeJS() {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.z = 4;

  const renderer = new THREE.WebGLRenderer({ 
    canvas: canvas, 
    antialias: true 
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const geometry = new THREE.TorusKnotGeometry(1, 0.3, 100, 16);
  const material = new THREE.MeshStandardMaterial({
    color: 0xff4757,
    transparent: true,
    opacity: 0.8
  });

  const torus = new THREE.Mesh(geometry, material);
  scene.add(torus);

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(5, 5, 5);
  scene.add(light);

  const ambient = new THREE.AmbientLight(0x404040);
  scene.add(ambient);

  const light2 = new THREE.PointLight(0xff4757, 0.5);
  light2.position.set(2, 2, 3);
  scene.add(light2);

  function animate() {
    torus.rotation.x += 0.01;
    torus.rotation.y += 0.01;
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
}

function initGSAPAnimations() {
  const tl = gsap.timeline({ defaults: { duration: 1, ease: 'power2.out' } });

  tl.from('header', { y: -100, opacity: 0 })
    .from('.hero h1', { y: 50, opacity: 0 }, '-=0.8')
    .from('.hero p', { y: 30, opacity: 0 }, '-=0.6')
    .from('.cta-buttons', { y: 30, opacity: 0, scale: 0.8 }, '-=0.4')
    .from('.nav-links a', { y: 20, opacity: 0, stagger: 0.2 }, '-=0.5');

  gsap.from('.section-label', {
    y: -50,
    opacity: 0,
    scroll: {
      trigger: '#range',
      start: 'top 80%'
    }
  });

  gsap.from('.product-card', {
    y: 50,
    opacity: 0,
    stagger: 0.2,
    scroll: {
      trigger: '#range',
      start: 'top 80%',
      end: 'bottom 20%'
    }
  });

  gsap.from('.microcopy', {
    y: 30,
    opacity: 0,
    scroll: {
      trigger: 'body',
      start: 'bottom 80%'
    }
  });

  gsap.from('.floating-action', {
    y: 30,
    opacity: 0,
    rotation: -180,
    scroll: {
      trigger: 'body',
      start: 'bottom 50%'
    }
  });
}